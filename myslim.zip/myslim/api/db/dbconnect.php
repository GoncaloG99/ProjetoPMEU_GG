<?php
	include "NotORM.php";
	$user = "id17193360_root";
	$pass = "/TMzR(#-8_H*nM!K";
	$conn = new PDO('mysql:host=localhost;dbname=id17193360_cidadepmeu99;charset=utf8', $user, $pass);
	$db = new NotORM($conn);
?>